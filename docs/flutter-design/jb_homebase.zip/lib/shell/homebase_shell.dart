import 'package:flutter/material.dart';

import '../models/agent.dart';
import '../screens/chat_screen.dart';
import '../screens/dashboard_screen.dart';
import '../theme/jb_theme.dart';
import '../widgets/insights_widgets.dart';
import '../widgets/jb_widgets.dart';

/// HomebaseShell
/// -------------
/// Root layout. Mobile: content + floating pill nav. Wide screens
/// (>= 840dp): the same tabs render as a NavigationRail on the left —
/// the NotebookLM-style desktop posture. Tabs live in an IndexedStack
/// so screen state (chat threads, scroll positions) survives switching.
class HomebaseShell extends StatefulWidget {
  const HomebaseShell({super.key});

  @override
  State<HomebaseShell> createState() => _HomebaseShellState();
}

class _HomebaseShellState extends State<HomebaseShell> {
  int _index = 0;
  Agent? _chatAgent;

  // Opening an agent from the dashboard dock jumps into the chat tab
  // with that agent preselected.
  void _openAgent(Agent agent) => setState(() {
        _chatAgent = agent;
        _index = 1;
      });

  static const _tabs = [
    (icon: Icons.grid_view_rounded, label: 'Home'),
    (icon: Icons.chat_bubble_outline_rounded, label: 'Agents'),
    (icon: Icons.insights_rounded, label: 'Insights'),
  ];

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 840;

    final body = IndexedStack(
      index: _index,
      children: [
        DashboardScreen(onOpenAgent: _openAgent),
        ChatScreen(
          // Key forces re-init when the dock preselects a different agent.
          key: ValueKey(_chatAgent?.id ?? 'chat'),
          initialAgent: _chatAgent,
        ),
        const _InsightsScreen(),
      ],
    );

    if (wide) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              backgroundColor: Theme.of(context).colorScheme.surface,
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              labelType: NavigationRailLabelType.all,
              destinations: [
                for (final t in _tabs)
                  NavigationRailDestination(
                      icon: Icon(t.icon), label: Text(t.label)),
              ],
            ),
            Expanded(child: body),
          ],
        ),
      );
    }

    return Scaffold(
      extendBody: true, // content scrolls beneath the floating nav
      body: body,
      bottomNavigationBar: _FloatingNav(
        index: _index,
        tabs: _tabs,
        onSelect: (i) => setState(() => _index = i),
      ),
    );
  }
}

/// Floating pill navigation. The active tab expands to show its label;
/// inactive tabs collapse to icons — the expansion is the micro-interaction.
class _FloatingNav extends StatelessWidget {
  const _FloatingNav(
      {required this.index, required this.tabs, required this.onSelect});

  final int index;
  final List<({IconData icon, String label})> tabs;
  final void Function(int) onSelect;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.fromLTRB(40, 0, 40, 12),
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(40),
          boxShadow: JBTheme.softShadow(context),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(tabs.length, (i) {
            final selected = i == index;
            return BouncyButton(
              onTap: () => onSelect(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.symmetric(
                    horizontal: selected ? 18 : 14, vertical: 12),
                decoration: BoxDecoration(
                  color: selected
                      ? theme.colorScheme.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      tabs[i].icon,
                      size: 22,
                      color: selected
                          ? theme.colorScheme.onPrimary
                          : theme.colorScheme.onSurface
                              .withValues(alpha: 0.65),
                    ),
                    // Label slides open only for the active tab.
                    AnimatedSize(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOutCubic,
                      child: selected
                          ? Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                tabs[i].label,
                                style: theme.textTheme.labelLarge?.copyWith(
                                    color: theme.colorScheme.onPrimary),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

/// Insights tab: the analytics/calendar architecture, assembled from the
/// same placeholder widgets the dashboard previews. Grows into the full
/// analytics dashboard later.
class _InsightsScreen extends StatelessWidget {
  const _InsightsScreen();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: JBTheme.pagePadding.copyWith(top: 24, bottom: 120),
        children: [
          FadeSlideIn(
            child: Text('Insights', style: theme.textTheme.displayMedium),
          ),
          const SizedBox(height: 24),
          const FadeSlideIn(
            delay: Duration(milliseconds: 100),
            child: WeekStripe(),
          ),
          const SizedBox(height: 16),
          const FadeSlideIn(
            delay: Duration(milliseconds: 180),
            child: SparklineCard(),
          ),
          const SizedBox(height: 16),
          FadeSlideIn(
            delay: const Duration(milliseconds: 260),
            child: SparklineCard(
              title: 'Weekly volume',
              caption: 'Hours per week, last 14 weeks',
              values: const [4, 4.5, 5, 4, 6, 5.5, 6.5, 7, 6, 7.5, 8, 7, 8.5, 9],
            ),
          ),
        ],
      ),
    );
  }
}
