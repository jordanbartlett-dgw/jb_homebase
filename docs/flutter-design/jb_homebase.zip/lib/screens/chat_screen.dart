import 'package:flutter/material.dart';

import '../models/agent.dart';
import '../theme/jb_theme.dart';
import '../widgets/jb_widgets.dart';

/// ChatScreen
/// ----------
/// Distraction-free chat with an agent picker in the header. Switching
/// agents slides the whole thread horizontally (direction follows roster
/// order) via AnimatedSwitcher keyed on agent id.
///
/// State is deliberately local + in-memory. When wiring to Jordan Claw,
/// replace [_threads] with a provider that streams messages per agent.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, this.initialAgent});

  final Agent? initialAgent;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late Agent _agent = widget.initialAgent ?? Agent.roster.first;
  int _slideDirection = 1; // +1 slide from right, -1 from left
  bool _agentTyping = false;
  final _input = TextEditingController();
  final _scroll = ScrollController();

  // Placeholder threads, keyed by agent id.
  final Map<String, List<ChatMessage>> _threads = {
    'general': [
      const ChatMessage(
          text: 'Morning. Your digest is ready and I moved two low-priority '
              'emails to the follow-up list.',
          fromUser: false),
    ],
    'workout': [
      const ChatMessage(
          text: 'Hill repeats today: 6 x 90s at the neighborhood hill. '
              'Ready when you are.',
          fromUser: false),
    ],
  };

  void _selectAgent(Agent agent) {
    if (agent.id == _agent.id) return;
    final from = Agent.roster.indexWhere((a) => a.id == _agent.id);
    final to = Agent.roster.indexWhere((a) => a.id == agent.id);
    setState(() {
      _slideDirection = to > from ? 1 : -1;
      _agent = agent;
    });
  }

  void _send() {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _threads[_agent.id]!.add(ChatMessage(text: text, fromUser: true));
      _input.clear();
      _agentTyping = true;
    });
    _scrollToEnd();

    // Placeholder reply — replace with gateway stream.
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      setState(() {
        _agentTyping = false;
        _threads[_agent.id]!.add(const ChatMessage(
            text: 'Got it — on it now.', fromUser: false));
      });
      _scrollToEnd();
    });
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final messages = _threads[_agent.id] ?? const <ChatMessage>[];

    return SafeArea(
      child: Column(
        children: [
          _AgentPicker(selected: _agent, onSelect: _selectAgent),
          const SizedBox(height: 8),

          // Thread slides horizontally when the agent changes.
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 380),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) {
                final incoming = child.key == ValueKey(_agent.id);
                final begin = Offset(
                    incoming ? 0.15 * _slideDirection : -0.15 * _slideDirection,
                    0);
                return FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween(begin: begin, end: Offset.zero)
                        .animate(animation),
                    child: child,
                  ),
                );
              },
              child: ListView.builder(
                key: ValueKey(_agent.id),
                controller: _scroll,
                padding: JBTheme.pagePadding.copyWith(top: 8, bottom: 16),
                itemCount: messages.length + (_agentTyping ? 1 : 0),
                itemBuilder: (context, i) {
                  if (i == messages.length) {
                    return _TypingIndicator(tint: _agent.tint);
                  }
                  return _ChatBubble(message: messages[i], agent: _agent);
                },
              ),
            ),
          ),

          _Composer(controller: _input, onSend: _send, hint: _agent.name),
        ],
      ),
    );
  }
}

/// Horizontal agent chips. Selected chip fills with the agent tint.
class _AgentPicker extends StatelessWidget {
  const _AgentPicker({required this.selected, required this.onSelect});

  final Agent selected;
  final void Function(Agent) onSelect;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: JBTheme.pagePadding.copyWith(top: 4),
        itemCount: Agent.roster.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) {
          final agent = Agent.roster[i];
          final isSelected = agent.id == selected.id;
          return BouncyButton(
            onTap: () => onSelect(agent),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOut,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected
                    ? agent.tint
                    : theme.colorScheme.surfaceContainerHighest
                        .withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Row(
                children: [
                  Icon(agent.icon,
                      size: 16,
                      color: isSelected
                          ? JBColors.cream
                          : theme.colorScheme.onSurface),
                  const SizedBox(width: 8),
                  Text(
                    agent.name,
                    style: theme.textTheme.labelLarge?.copyWith(
                      color: isSelected
                          ? JBColors.cream
                          : theme.colorScheme.onSurface,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Asymmetric-radius bubbles per the spec:
/// user   → rounded everywhere except a sharp bottom-right
/// agent  → rounded everywhere except a sharp bottom-left
class _ChatBubble extends StatelessWidget {
  const _ChatBubble({required this.message, required this.agent});

  final ChatMessage message;
  final Agent agent;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final fromUser = message.fromUser;
    const r = Radius.circular(JBTheme.radiusBubble);
    const sharp = Radius.circular(4);

    return Align(
      alignment: fromUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: fromUser
              ? theme.colorScheme.primary
              : theme.colorScheme.surface,
          borderRadius: BorderRadius.only(
            topLeft: r,
            topRight: r,
            bottomLeft: fromUser ? r : sharp,
            bottomRight: fromUser ? sharp : r,
          ),
          boxShadow: fromUser ? null : JBTheme.softShadow(context),
        ),
        child: Text(
          message.text,
          style: theme.textTheme.bodyLarge?.copyWith(
            color: fromUser
                ? theme.colorScheme.onPrimary
                : theme.colorScheme.onSurface,
          ),
        ),
      ),
    );
  }
}

/// Three-dot typing indicator with a gentle staggered pulse.
class _TypingIndicator extends StatefulWidget {
  const _TypingIndicator({required this.tint});
  final Color tint;

  @override
  State<_TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<_TypingIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(JBTheme.radiusBubble),
            topRight: Radius.circular(JBTheme.radiusBubble),
            bottomRight: Radius.circular(JBTheme.radiusBubble),
            bottomLeft: Radius.circular(4),
          ),
        ),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              // Stagger each dot a third of a cycle apart.
              final t = (_controller.value + i / 3) % 1.0;
              final pulse = (t < 0.5 ? t : 1 - t) * 2; // triangle wave 0..1
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.tint.withValues(alpha: 0.35 + 0.5 * pulse),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

/// Message composer pinned to the bottom.
class _Composer extends StatelessWidget {
  const _Composer(
      {required this.controller, required this.onSend, required this.hint});

  final TextEditingController controller;
  final VoidCallback onSend;
  final String hint;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: JBTheme.pagePadding.copyWith(top: 8, bottom: 12),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(26),
                boxShadow: JBTheme.softShadow(context),
              ),
              child: TextField(
                controller: controller,
                onSubmitted: (_) => onSend(),
                textInputAction: TextInputAction.send,
                style: theme.textTheme.bodyLarge,
                decoration: InputDecoration(
                  hintText: 'Message $hint',
                  hintStyle: theme.textTheme.bodyMedium
                      ?.copyWith(color: theme.colorScheme.outline),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          BouncyButton(
            onTap: onSend,
            child: Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.arrow_upward_rounded,
                  color: theme.colorScheme.onPrimary),
            ),
          ),
        ],
      ),
    );
  }
}
