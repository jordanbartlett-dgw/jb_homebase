import 'package:flutter/material.dart';

import 'shell/homebase_shell.dart';
import 'theme/jb_theme.dart';

/// JB Homebase — command center for Jordan Claw agents.
///
/// pubspec.yaml additions:
///   dependencies:
///     google_fonts: ^6.2.1
///     intl: ^0.19.0
void main() => runApp(const JBHomebaseApp());

class JBHomebaseApp extends StatelessWidget {
  const JBHomebaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JB Homebase',
      debugShowCheckedModeBanner: false,
      theme: JBTheme.light,
      darkTheme: JBTheme.dark,
      themeMode: ThemeMode.system,
      home: const HomebaseShell(),
    );
  }
}
