import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// JBTheme
/// -------
/// Single source of truth for JB Homebase visual identity.
///
/// Palette philosophy: deep slates for grounding, warm creams for air,
/// sage as the single accent. Sage is spent deliberately — active states,
/// the digest gradient, and nothing else. Everything else stays quiet.
///
/// Fonts: Playfair Display (display, used sparingly: greeting + card
/// headlines) paired with Inter (body/UI). Requires `google_fonts` in
/// pubspec.yaml.
class JBColors {
  JBColors._();

  // Core palette
  static const cream = Color(0xFFF6F1E7); // warm cream — light bg
  static const creamElevated = Color(0xFFFDFAF3); // cards on cream
  static const mist = Color(0xFFE8E2D4); // dividers, subtle fills
  static const deepSlate = Color(0xFF1B222B); // dark bg / light-mode ink
  static const slate = Color(0xFF2A333F); // dark-mode surface
  static const slateElevated = Color(0xFF333E4C); // dark-mode cards
  static const sage = Color(0xFF9CB39A); // primary accent
  static const sageDeep = Color(0xFF64805F); // accent on light bg
  static const inkMuted = Color(0xFF6B7280); // secondary text (light)
  static const creamMuted = Color(0xFFB4AFA3); // secondary text (dark)

  // Digest gradient — the one loud moment on the dashboard.
  static const digestGradientLight = [Color(0xFF64805F), Color(0xFF3C4A3E)];
  static const digestGradientDark = [Color(0xFF4C6249), Color(0xFF232B26)];
}

class JBTheme {
  JBTheme._();

  /// Shared radii and spacing so components stay consistent.
  static const radiusCard = 24.0;
  static const radiusBubble = 20.0;
  static const pagePadding = EdgeInsets.symmetric(horizontal: 24);

  static ThemeData get light => _build(Brightness.light);
  static ThemeData get dark => _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final isDark = brightness == Brightness.dark;

    final bg = isDark ? JBColors.deepSlate : JBColors.cream;
    final surface = isDark ? JBColors.slate : JBColors.creamElevated;
    final ink = isDark ? JBColors.cream : JBColors.deepSlate;
    final muted = isDark ? JBColors.creamMuted : JBColors.inkMuted;
    final accent = isDark ? JBColors.sage : JBColors.sageDeep;

    final scheme = ColorScheme(
      brightness: brightness,
      primary: accent,
      onPrimary: isDark ? JBColors.deepSlate : JBColors.cream,
      secondary: JBColors.sage,
      onSecondary: JBColors.deepSlate,
      surface: surface,
      onSurface: ink,
      surfaceContainerHighest: isDark ? JBColors.slateElevated : JBColors.mist,
      error: const Color(0xFFB3543F),
      onError: JBColors.cream,
      outline: muted.withValues(alpha: 0.4),
    );

    // Display = Playfair (restraint: greeting, card headlines).
    // Everything functional = Inter.
    final textTheme = TextTheme(
      displayLarge: GoogleFonts.playfairDisplay(
          fontSize: 40, fontWeight: FontWeight.w600, color: ink, height: 1.1),
      displayMedium: GoogleFonts.playfairDisplay(
          fontSize: 30, fontWeight: FontWeight.w600, color: ink, height: 1.15),
      headlineSmall: GoogleFonts.playfairDisplay(
          fontSize: 22, fontWeight: FontWeight.w600, color: ink),
      titleMedium: GoogleFonts.inter(
          fontSize: 16, fontWeight: FontWeight.w600, color: ink),
      titleSmall: GoogleFonts.inter(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: muted,
          letterSpacing: 1.2), // eyebrow labels, uppercase in usage
      bodyLarge: GoogleFonts.inter(fontSize: 16, color: ink, height: 1.5),
      bodyMedium: GoogleFonts.inter(fontSize: 14, color: ink, height: 1.5),
      bodySmall: GoogleFonts.inter(fontSize: 12, color: muted),
      labelLarge: GoogleFonts.inter(
          fontSize: 14, fontWeight: FontWeight.w600, color: ink),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
      textTheme: textTheme,
      splashFactory: NoSplash.splashFactory, // BouncyButton owns tactility
      highlightColor: Colors.transparent,
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusCard)),
        margin: EdgeInsets.zero,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.headlineSmall,
        iconTheme: IconThemeData(color: ink),
      ),
      dividerTheme: DividerThemeData(
          color: scheme.outline.withValues(alpha: 0.25), thickness: 1),
    );
  }

  /// Soft, diffuse drop shadow used on elevated cards. Kept here so every
  /// card lifts identically.
  static List<BoxShadow> softShadow(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return [
      BoxShadow(
        color: (isDark ? Colors.black : JBColors.deepSlate)
            .withValues(alpha: isDark ? 0.35 : 0.08),
        blurRadius: 30,
        offset: const Offset(0, 12),
      ),
    ];
  }
}
