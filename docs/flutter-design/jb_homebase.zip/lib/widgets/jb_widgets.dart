import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// BouncyButton
/// ------------
/// Reflectly-style tactile press: scales to [pressedScale] on pointer-down,
/// springs back on release. Fires light haptic feedback so presses feel
/// physical. Wrap any card or control.
class BouncyButton extends StatefulWidget {
  const BouncyButton({
    super.key,
    required this.child,
    this.onTap,
    this.pressedScale = 0.96,
    this.haptics = true,
  });

  final Widget child;
  final VoidCallback? onTap;
  final double pressedScale;
  final bool haptics;

  @override
  State<BouncyButton> createState() => _BouncyButtonState();
}

class _BouncyButtonState extends State<BouncyButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 110),
    reverseDuration: const Duration(milliseconds: 220),
  );

  // easeOutBack on release gives the slight overshoot that reads "bouncy".
  late final Animation<double> _scale = Tween(begin: 1.0, end: widget.pressedScale)
      .animate(CurvedAnimation(
    parent: _controller,
    curve: Curves.easeOut,
    reverseCurve: Curves.easeOutBack,
  ));

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _down(_) => _controller.forward();

  void _up(_) {
    _controller.reverse();
    if (widget.haptics) HapticFeedback.lightImpact();
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: _down,
      onTapUp: _up,
      onTapCancel: _controller.reverse,
      child: ScaleTransition(scale: _scale, child: widget.child),
    );
  }
}

/// FadeSlideIn
/// -----------
/// Cinematic entrance: fades in while sliding from [offset]. Use [delay]
/// to stagger siblings (Wonderous-style orchestration) without any
/// animation package. Respects reduced-motion settings.
class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 550),
    this.offset = const Offset(0, 0.08),
    this.curve = Curves.easeOutCubic,
  });

  final Widget child;
  final Duration delay;
  final Duration duration;

  /// Fractional offset (relative to child size), e.g. (0, 0.08) = slide up 8%.
  final Offset offset;
  final Curve curve;

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> {
  bool _visible = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(widget.delay, () {
      if (mounted) setState(() => _visible = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    // Accessibility: skip motion if the OS asks for it.
    if (MediaQuery.of(context).disableAnimations) return widget.child;

    return AnimatedOpacity(
      opacity: _visible ? 1 : 0,
      duration: widget.duration,
      curve: widget.curve,
      child: AnimatedSlide(
        offset: _visible ? Offset.zero : widget.offset,
        duration: widget.duration,
        curve: widget.curve,
        child: widget.child,
      ),
    );
  }
}
